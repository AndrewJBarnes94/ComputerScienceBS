package PROGRAMMING_2.CTA4;

public abstract class Shape {
    public abstract double surfaceArea();
    public abstract double volume();
}
