#--------------------------------------------------------
# Program Name: Module 1 CT Assignment - Option 1
# Program Author: Andrew Barnes
# Program Objective: Draw a mouse
#--------------------------------------------------------
# Pseudocode: 1. print out strings of symbols until
#                a mouse is created
#--------------------------------------------------------
# Program Inputs: None
# Program Outputs: A mouse
#-------------------------------------------------------- 

print("          (\--.")
print(" _)       /  _`>")
print("(        /  _)=")
print(" `.     /  _/")
print("   `.__(____)__")