//============================================================================
// Name        : CTA1.cpp
// Author      : Andrew Barnes
// Version     : 1
// Description : Basic Console Application for Programming 3 CTA1
//============================================================================

#include<iostream>;

using namespace std;

int main() {
	string firstName = "Andrew";
	string lastName = "Barnes";
	string streetAddress = "123 Main Street";
	string city = "Saint Petersburg, FL";
	int zipCode = 12345;

	cout << firstName << endl;
	cout << lastName << endl;
	cout << streetAddress << endl;
	cout << city << endl;
	cout << zipCode << endl;

	return 0;
}
